import { Component } from '@angular/core';
import { PROJECTS } from '../../../../data/project-gallery.data';

@Component({
  selector: 'app-project-gallery',
  standalone: true,
  imports: [],
  templateUrl: './project-gallery.component.html',
  styleUrl: './project-gallery.component.css',
})
export class ProjectGalleryComponent {
  projects = PROJECTS;
}
