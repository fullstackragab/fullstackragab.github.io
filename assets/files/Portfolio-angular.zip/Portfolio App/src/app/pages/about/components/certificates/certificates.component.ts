import { Component } from '@angular/core';
import { CERTIFICATES } from '../../../../data/certificates.data';

@Component({
  selector: 'app-certificates',
  standalone: true,
  imports: [],
  templateUrl: './certificates.component.html',
  styleUrl: './certificates.component.css',
})
export class CertificatesComponent {
  certificates = CERTIFICATES;
}
