import { Component } from '@angular/core';
import { BioComponent } from './components/bio/bio.component';
import { CertificatesComponent } from './components/certificates/certificates.component';

@Component({
  selector: 'app-about',
  standalone: true,
  imports: [BioComponent, CertificatesComponent],
  templateUrl: './about.component.html',
  styleUrl: './about.component.css',
})
export class AboutComponent {}
