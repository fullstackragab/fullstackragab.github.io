import { Component } from '@angular/core';
import { LocationMapComponent } from './components/location-map/location-map.component';
import { ContactInfoComponent } from './components/contact-info/contact-info.component';

@Component({
  selector: 'app-contact',
  standalone: true,
  imports: [LocationMapComponent, ContactInfoComponent],
  templateUrl: './contact.component.html',
  styleUrl: './contact.component.css',
})
export class ContactComponent {}
