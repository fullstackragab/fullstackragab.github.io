import { Component } from '@angular/core';
import { EXPERIENCES } from '../../../../data/experiences.data';

@Component({
  selector: 'app-experiences',
  standalone: true,
  imports: [],
  templateUrl: './experiences.component.html',
  styleUrl: './experiences.component.css',
})
export class ExperiencesComponent {
  experiences = EXPERIENCES;
}
