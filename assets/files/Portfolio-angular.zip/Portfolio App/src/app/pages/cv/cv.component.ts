import { Component } from '@angular/core';
import { ExperiencesComponent } from './components/experiences/experiences.component';
import { DownloadCvComponent } from './components/download-cv/download-cv.component';

@Component({
  selector: 'app-cv',
  standalone: true,
  imports: [ExperiencesComponent, DownloadCvComponent],
  templateUrl: './cv.component.html',
  styleUrl: './cv.component.css',
})
export class CvComponent {}
