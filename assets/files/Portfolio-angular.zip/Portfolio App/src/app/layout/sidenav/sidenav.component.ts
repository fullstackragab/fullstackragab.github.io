import { CommonModule } from '@angular/common';
import { Component, EventEmitter, Input, Output } from '@angular/core';
import { SIDENAV_ITEMS } from '../../services/sidenav.service';

@Component({
  selector: 'app-sidenav',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './sidenav.component.html',
  styleUrl: './sidenav.component.css',
})
export class SidenavComponent {
  sidenavItems = SIDENAV_ITEMS;
  @Input() opened = false;
  @Output() itemClicked = new EventEmitter<string>();
  onItemClicked(itemName: string) {
    this.itemClicked.next(itemName);
  }
}
