export interface Certificate {
  title: string;
  imageUrl: string;
}

export const CERTIFICATES: Certificate[] = [
  {
    title: 'Software Design and Architecture - University of Alberta',
    imageUrl: 'assets/images/certificates/architecture.png',
  },
  {
    title:
      'Improve Your English Communication Skills - Georgia Institute of Technology',
    imageUrl: 'assets/images/certificates/english.png',
  },
  {
    title: 'Microservices Foundations - LinkedIn',
    imageUrl: 'assets/images/certificates/microservices.png',
  },
  {
    title: 'Ionic - Udemy',
    imageUrl: 'assets/images/certificates/ionic.png',
  },
  {
    title: 'AWS Certified Solutions Architect - Associate',
    imageUrl: 'assets/images/certificates/aws.png',
  },
  {
    title: 'Oracle Certified Professional, Java SE 11 Programmer',
    imageUrl: 'assets/images/certificates/java-2.png',
  },
];
