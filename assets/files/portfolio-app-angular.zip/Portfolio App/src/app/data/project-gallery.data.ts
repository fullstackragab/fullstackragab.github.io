export interface Project {
  title: string;
  imageUrl: string;
}

export const PROJECTS: Project[] = [
  { title: 'Project 1', imageUrl: 'assets/images/projects/project-1.jpg' },
  { title: 'Project 2', imageUrl: 'assets/images/projects/project-2.jpg' },
  { title: 'Project 3', imageUrl: 'assets/images/projects/project-3.jpg' },
];
