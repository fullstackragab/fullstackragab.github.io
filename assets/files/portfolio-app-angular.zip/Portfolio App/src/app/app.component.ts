import { Component, Injector, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, RouterOutlet } from '@angular/router';
import { SidenavService } from './services/sidenav.service';
import { SidenavComponent } from './layout/sidenav/sidenav.component';
import { TopBarComponent } from './layout/top-bar/top-bar.component';
import { FooterComponent } from './layout/footer/footer.component';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [
    CommonModule,
    RouterOutlet,
    TopBarComponent,
    SidenavComponent,
    FooterComponent,
  ],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css',
})
export class AppComponent implements OnInit {
  opened = false;
  sidenavService!: SidenavService;
  router!: Router;
  constructor(private injector: Injector) {}
  ngOnInit() {
    this.router = this.injector.get(Router);
    this.sidenavService = this.injector.get(SidenavService);
    this.sidenavService.opened.subscribe((opened) => (this.opened = opened));
  }
  onItemClicked(itemName: string) {
    this.router.navigate(['/', itemName]);
    this.sidenavService.close();
  }
}
