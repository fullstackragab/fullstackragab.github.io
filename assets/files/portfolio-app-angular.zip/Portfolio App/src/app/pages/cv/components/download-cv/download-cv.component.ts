import { Component } from '@angular/core';

@Component({
  selector: 'app-download-cv',
  standalone: true,
  imports: [],
  templateUrl: './download-cv.component.html',
  styleUrl: './download-cv.component.css'
})
export class DownloadCvComponent {

}
