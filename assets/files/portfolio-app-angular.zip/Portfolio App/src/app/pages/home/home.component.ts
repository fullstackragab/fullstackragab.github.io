import { Component } from '@angular/core';
import { PromotionComponent } from './components/promotion/promotion.component';
import { WelcomeComponent } from './components/welcome/welcome.component';
import { BadgesComponent } from './components/badges/badges.component';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [PromotionComponent, WelcomeComponent, BadgesComponent],
  templateUrl: './home.component.html',
  styleUrl: './home.component.css',
})
export class HomeComponent {}
