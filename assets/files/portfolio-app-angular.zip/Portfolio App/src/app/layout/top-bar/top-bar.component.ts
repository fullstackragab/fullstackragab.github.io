import { CommonModule } from '@angular/common';
import { Component, Injector } from '@angular/core';
import { RouterModule } from '@angular/router';
import { SidenavService } from '../../services/sidenav.service';

@Component({
  selector: 'app-top-bar',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './top-bar.component.html',
  styleUrl: './top-bar.component.css',
})
export class TopBarComponent {
  sidenavService!: SidenavService;
  constructor(private injector: Injector) {
    this.sidenavService = this.injector.get(SidenavService);
  }
  toggleSidenav() {
    this.sidenavService.toggle();
  }
}
