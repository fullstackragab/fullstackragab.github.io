import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-btn-continue',
  standalone: true,
  imports: [RouterLink],
  templateUrl: './btn-continue.component.html',
  styleUrl: './btn-continue.component.css',
})
export class BtnContinueComponent {}
