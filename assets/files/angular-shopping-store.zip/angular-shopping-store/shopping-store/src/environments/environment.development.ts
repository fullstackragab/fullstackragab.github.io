export const environment = {
  STRIPE_PK: 'USE YOUR STRIPE PUBLIC KEY',
};
