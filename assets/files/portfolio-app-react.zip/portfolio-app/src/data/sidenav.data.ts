export interface SidenavItem {
  title: string;
  path: string;
}

export const SIDENAV_ITEMS: SidenavItem[] = [
  { title: "Home", path: "home" },
  { title: "About", path: "about" },
  { title: "CV", path: "cv" },
  { title: "Projects", path: "projects" },
  { title: "Contact", path: "contact" },
];
