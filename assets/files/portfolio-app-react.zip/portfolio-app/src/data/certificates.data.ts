export interface Certificate {
  title: string;
  imageUrl: string;
}

export const CERTIFICATES: Certificate[] = [
  {
    title: "Software Design and Architecture - University of Alberta",
    imageUrl: "images/certificates/architecture.png",
  },
  {
    title:
      "Improve Your English Communication Skills - Georgia Institute of Technology",
    imageUrl: "images/certificates/english.png",
  },
  {
    title: "Microservices Foundations - LinkedIn",
    imageUrl: "images/certificates/microservices.png",
  },
  {
    title: "Ionic - Udemy",
    imageUrl: "images/certificates/ionic.png",
  },
  {
    title: "AWS Certified Solutions Architect - Associate",
    imageUrl: "images/certificates/aws.png",
  },
  {
    title: "Oracle Certified Professional, Java SE 11 Programmer",
    imageUrl: "images/certificates/java-2.png",
  },
];
