export interface Project {
  title: string;
  imageUrl: string;
}

export const PROJECTS: Project[] = [
  { title: "Project 1", imageUrl: "images/projects/project-1.jpg" },
  { title: "Project 2", imageUrl: "images/projects/project-2.jpg" },
  { title: "Project 3", imageUrl: "images/projects/project-3.jpg" },
];
