export interface Experience {
  title: string;
  subtitle: string;
  linesHeader: string;
  lines: string[];
}

export const EXPERIENCES: Experience[] = [
  {
    title: "Senior Software Developer - Angular",
    subtitle: "2019 - Present",
    linesHeader: "Working for clients online",
    lines: [
      "Developing and implementing user interface components",
      "Collaborating with cross-functional teams to analyze requirements",
      "Designing and implementing scalable and efficient solutions",
      "Writing clean, maintainable, and testable code",
    ],
  },
  {
    title: "Senior Software Developer - Java/Angular",
    subtitle: "2017 - 2019",
    linesHeader: "Work for the company siParadigm",
    lines: [
      "Troubleshooting complex issues in Angular applications",
      "Conducting code reviews to ensure code quality and performance",
      "Collaborating with UI/UX designers to ensure the feasibility",
      "Optimizing application performance by identifying bottlenecks",
    ],
  },
  {
    title: "Senior Software Developer - .NET/Angular",
    subtitle: "2014 - 2017",
    linesHeader: "Work for clients online",
    lines: [
      "Integrating third-party libraries and APIs into Angular applications",
      "Collaborating with backend developers to design RESTful APIs",
      "Implementing and maintaining unit tests and end-to-end tests",
      "Participating in Agile development processes, including sprint planning",
    ],
  },
];
