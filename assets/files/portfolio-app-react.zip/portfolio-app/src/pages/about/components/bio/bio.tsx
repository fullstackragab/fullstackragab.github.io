import "./bio.css";

function Bio() {
  return (
    <section className="bio">
      <p>
        I am Abdelfattah Ragab, a Senior Software Developer with extensive
        experience of over 20 years in the field. My expertise lies in frontend
        technologies, with a particular focus on the Angular framework.
      </p>
      <p>
        Throughout my career, I have honed my skills and knowledge to become
        proficient in creating exceptional user interfaces and crafting seamless
        web experiences. My passion for frontend development drives me to stay
        up-to-date with the latest tools and techniques, enabling me to deliver
        high-quality solutions to complex problems.
      </p>
      <p>
        With a proven track record of successful projects, I am recognized for
        my professionalism, attention to detail, and commitment to achieving
        outstanding results.
      </p>
    </section>
  );
}

export default Bio;
