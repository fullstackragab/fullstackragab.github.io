import { Certificate, CERTIFICATES } from "../../../../data/certificates.data";
import "./certificates.css";

function Certificates() {
  const createCertificateElement = (certificate: Certificate) => (
    <img
      key={certificate.title}
      src={certificate.imageUrl}
      alt={certificate.title}
      title={certificate.title}
      className="certificate link"
    />
  );
  return (
    <section className="certificates">
      {CERTIFICATES.map(createCertificateElement)}
    </section>
  );
}

export default Certificates;
