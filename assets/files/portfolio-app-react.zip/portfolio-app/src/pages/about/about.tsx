import Bio from "./components/bio/bio";
import Certificates from "./components/certificates/certificates";

function About() {
  return (
    <>
      <header className="main-title">About</header>
      <Bio />
      <Certificates />
    </>
  );
}

export default About;
