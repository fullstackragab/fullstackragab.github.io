import "./contact-info.css";

function ContactInfo() {
  return (
    <section className="contact-info">
      <p>Giza, Giza Governorate, Egypt</p>
      <p>Abdelfattah Ragab</p>
      <p>
        +20 11 423 69 630
        <br />
        +20 11 185 06 122
      </p>
      <p>
        fullstackragab&#64;gmail.com
        <br />
        contact&#64;abdelfattah-ragab.com
        <br />
        sales&#64;abdelfattah-ragab.com
      </p>
    </section>
  );
}

export default ContactInfo;
