import "./location-map.css";

function LocationMap() {
  return (
    <iframe
      src="https://www.google.com/maps/embed?pb=!1m14!1m12!1m3!1d86507.44890895384!2d30.940485229641485!3d29.992115477340583!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!5e0!3m2!1sen!2seg!4v1679596424897!5m2!1sen!2seg"
      className="map"
      allowFullScreen={true}
      loading="lazy"
      referrerPolicy="no-referrer-when-downgrade"
    ></iframe>
  );
}

export default LocationMap;
