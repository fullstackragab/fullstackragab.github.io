import ContactInfo from "./components/contact-info/contact-info";
import LocationMap from "./components/location-map/location-map";

function Contact() {
  return (
    <>
      <header className="main-title">Contact</header>
      <LocationMap />
      <ContactInfo />
    </>
  );
}

export default Contact;
