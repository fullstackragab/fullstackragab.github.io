import "./badges.css";

function Badges() {
  return (
    <section className="badges">
      <img
        src="images/badges/angular.png"
        alt=""
        title="Expert Angular Developer - Certified Level 3"
        className="badge link"
      />
      <img
        src="images/badges/oracle.png"
        alt=""
        title="Oracle Certified Professional: Java SE 11 Developer"
        className="badge link"
      />
      <img
        src="images/badges/google.png"
        alt=""
        title="Google Cloud Certified Professional Cloud Architect"
        className="badge link"
      />
      <img
        src="images/badges/aws.png"
        alt=""
        title="AWS Certified Solutions Architect Associate"
        className="badge link"
      />
    </section>
  );
}

export default Badges;
