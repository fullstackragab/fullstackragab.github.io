import "./promotion.css";

function Promotion() {
  return (
    <section className="promotion">
      <img
        src="images/promotion/book-mastering-css3.jpg"
        alt=""
        title="Mastering CSS3 A Comprehensive Guide to Modern Web Styling"
        className="book link"
      />
      <img
        src="images/promotion/book-mastering-html5.jpg"
        alt=""
        title="Mastering HTML5: The Complete Guide to Modern Web Development"
        className="book link"
      />
      <img
        src="images/promotion/course-hotel-booking-app.jpg"
        alt=""
        title="Creative CSS Projects: Hotel Booking App"
        className="course link"
      />
    </section>
  );
}
export default Promotion;
