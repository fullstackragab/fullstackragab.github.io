import "./welcome.css";

function Welcome() {
  return (
    <section className="welcome">
      <header className="welcome-header">Welcome to my website!</header>
      <div className="welcome-content">
        <p>Hello,</p>
        <p>
          I am Abdelfattah Ragab, a very experienced frontend developer with 20
          years of experience. With my knowledge of HTML, CSS and JavaScript, I
          am particularly good at creating user-friendly and visually appealing
          interfaces. Thanks to my in-depth knowledge of frontend frameworks and
          my passion for keeping up to date with industry trends, I have
          successfully completed numerous projects in my career. My leadership
          and mentoring skills have made me a valuable asset in
          multidisciplinary teams, while my commitment to continuous learning
          continues to drive my success in frontend development.
        </p>
        <p>
          My expertise extends to developing robust and scalable applications
          using Angular frameworks, always adhering to best practices and
          industry standards. With a passion for constant learning and
          recognizing new trends, I am committed to developing innovative
          solutions that drive business success. I have the ability to
          communicate complex concepts effectively.
        </p>
      </div>
    </section>
  );
}

export default Welcome;
