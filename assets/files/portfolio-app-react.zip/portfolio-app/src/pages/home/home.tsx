import Badges from "./components/badges/badges";
import Promotion from "./components/promotion/promotion";
import Welcome from "./components/welcome/welcome";

function Home() {
  return (
    <>
      <Promotion />
      <Welcome />
      <Badges />
    </>
  );
}

export default Home;
