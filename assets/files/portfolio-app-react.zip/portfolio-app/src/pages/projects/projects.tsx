import ProjectGallery from "./components/project-gallery/project-gallery";

function Projects() {
  return (
    <>
      <header className="main-title">Projects</header>
      <ProjectGallery />
    </>
  );
}

export default Projects;
