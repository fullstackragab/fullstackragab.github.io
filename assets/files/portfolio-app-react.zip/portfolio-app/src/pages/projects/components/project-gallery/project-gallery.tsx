import { PROJECTS, Project } from "../../../../data/project-gallery.data";
import "./project-gallery.css";

function ProjectGallery() {
  const createProjectElement = (project: Project) => (
    <img
      key={project.title}
      src={project.imageUrl}
      alt={project.title}
      title={project.title}
      className="project link"
    />
  );
  return <div className="projects">{PROJECTS.map(createProjectElement)}</div>;
}

export default ProjectGallery;
