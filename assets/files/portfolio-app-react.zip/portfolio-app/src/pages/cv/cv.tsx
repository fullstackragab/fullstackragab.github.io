import DownloadCV from "./components/download-cv/download-cv";
import Experiences from "./components/experiences/experiences";

function CV() {
  return (
    <>
      <header className="main-title">CV</header>
      <Experiences />
      <DownloadCV />
    </>
  );
}

export default CV;
