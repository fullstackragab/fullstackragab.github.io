import "./download-cv.css";

function DownloadCV() {
  return (
    <section className="download-cv">
      <a href="files/cv/Abdelfattah-CV.pdf" download>
        <img src="images/cv/Abdelfattah-CV-1.jpg" className="cv-imagg" />
      </a>
      <a href="files/cv/Abdelfattah-CV.pdf" download>
        <img src="images/cv/Abdelfattah-CV-2.jpg" className="cv-imagg" />
      </a>
      <a href="files/Abdelfattah-CV.pdf" className="download-button" download>
        Download
      </a>
    </section>
  );
}

export default DownloadCV;
