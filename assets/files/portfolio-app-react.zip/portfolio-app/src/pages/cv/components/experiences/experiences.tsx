import "./experiences.css";
import { EXPERIENCES, Experience } from "../../../../data/experiences.data";

function Experiences() {
  const createExperienceLine = (line: string) => <span key={line}>{line}</span>;
  const createExperienceElement = (experience: Experience) => (
    <section key={experience.title} className="experience">
      <div className="experience-header">
        <img className="experience-header-icon" src="images/cv/cv.svg" />
        <div className="experience-header-title">{experience.title}</div>
        <div className="experience-header-subtitle">{experience.subtitle}</div>
      </div>
      <div className="experience-content">
        <header>{experience.linesHeader}</header>
        {experience.lines.map(createExperienceLine)}
      </div>
    </section>
  );

  return <>{EXPERIENCES.map(createExperienceElement)}</>;
}

export default Experiences;
