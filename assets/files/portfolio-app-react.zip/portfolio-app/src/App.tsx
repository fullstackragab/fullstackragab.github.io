import "./App.css";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import TopBar from "./layout/top-bar/top-bar";
import Sidenav from "./layout/sidenav/sidenav";
import { useState } from "react";
import Footer from "./layout/footer/footer";
import Home from "./pages/home/home";
import About from "./pages/about/about";
import CV from "./pages/cv/cv";
import Projects from "./pages/projects/projects";
import Contact from "./pages/contact/contact";

function App() {
  const [opened, setOpened] = useState(false);

  return (
    <div>
      <BrowserRouter>
        <TopBar opened={opened} setOpened={setOpened} />
        <Sidenav opened={opened} setOpened={setOpened} />
        <main className="main">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/home" element={<Home />} />
            <Route path="/about" element={<About />} />
            <Route path="/cv" element={<CV />} />
            <Route path="/projects" element={<Projects />} />
            <Route path="/contact" element={<Contact />} />
          </Routes>
        </main>
        <Footer />
      </BrowserRouter>
    </div>
  );
}

export default App;
