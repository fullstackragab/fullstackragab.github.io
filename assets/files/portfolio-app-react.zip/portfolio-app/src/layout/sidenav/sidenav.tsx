import { useNavigate } from "react-router-dom";
import { SIDENAV_ITEMS, SidenavItem } from "../../data/sidenav.data";
import "./sidenav.css";

type Props = {
  opened: boolean;
  setOpened: any;
};

function Sidenav({ opened, setOpened }: Props) {
  const navigate = useNavigate();

  const onItemClicked = (path: string) => {
    navigate(path);
    setOpened(false);
  };
  const createSidenavItem = (item: SidenavItem) => (
    <div
      key={item.title}
      onClick={() => onItemClicked(item.path)}
      className="sidenav-item"
    >
      {item.title}
    </div>
  );
  return (
    <>
      <div className={`backdrop ${opened ? "backdrop-visible" : ""} `}></div>
      <nav className={`sidenav ${opened ? "sidenav-visible" : ""}`}>
        {SIDENAV_ITEMS.map(createSidenavItem)}
      </nav>
    </>
  );
}

export default Sidenav;
