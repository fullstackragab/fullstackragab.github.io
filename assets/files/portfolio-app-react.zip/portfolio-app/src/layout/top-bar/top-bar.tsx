import "./top-bar.css";

import { Link } from "react-router-dom";

type Props = {
  opened: boolean;
  setOpened: any;
};

function TopBar({ opened, setOpened }: Props) {
  function toggleSidenav() {
    setOpened(!opened);
  }
  return (
    <header className="top-bar">
      <div className="brand">
        <Link to="/">
          <img src="images/logo.png" alt="" className="logo link" />
        </Link>
        <Link to="/">
          <div className="brand-name link">Abdelfattah Ragab</div>
        </Link>
      </div>
      <div className="menu-button">
        <img
          src="images/other/menu.png"
          onClick={toggleSidenav}
          alt=""
          className="menu-icon link"
        />
      </div>
    </header>
  );
}

export default TopBar;
