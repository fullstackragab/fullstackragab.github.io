import "./footer.css";
import { Link } from "react-router-dom";
function Footer() {
  return (
    <footer className="footer">
      <section className="main-footer">
        <Link to="/about">
          <div className="link">About</div>
        </Link>
        <Link to="/cv">
          <div className="link">CV</div>
        </Link>
        <Link to="/projects">
          <div className="link">Projects</div>
        </Link>
        <Link to="/contact">
          <div className="link">Contact</div>
        </Link>
      </section>
      <div className="divider"></div>
      <section className="social-footer">
        <a href="">
          <img
            src="images/social/linkedin.png"
            alt=""
            className="social-icon"
          />
        </a>
        <a href="">
          <img
            src="images/social/facebook.png"
            alt=""
            className="social-icon"
          />
        </a>
        <a href="">
          <img
            src="images/social/instagram.png"
            alt=""
            className="social-icon"
          />
        </a>
        <a href="">
          <img
            src="images/social/youtube.png"
            alt=""
            className="social-icon youtube-icon"
          />
        </a>
      </section>
      <div className="divider"></div>
      <section className="copyright-footer">
        <p>©2024 by Abdelfattah Ragab, all rights reserved.</p>
      </section>
    </footer>
  );
}

export default Footer;
