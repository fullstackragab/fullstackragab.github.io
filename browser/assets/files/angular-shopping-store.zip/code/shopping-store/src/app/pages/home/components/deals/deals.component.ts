import { Component } from '@angular/core';

@Component({
  selector: 'app-deals',
  standalone: true,
  imports: [],
  templateUrl: './deals.component.html',
  styleUrl: './deals.component.css'
})
export class DealsComponent {

}
