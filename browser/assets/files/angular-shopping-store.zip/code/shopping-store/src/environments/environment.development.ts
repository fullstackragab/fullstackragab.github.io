export const environment = {
  STRIPE_PK: 'YOUR_STRIPE_PUBLIC_KEY',
};
